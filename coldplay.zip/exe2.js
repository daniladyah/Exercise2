video.addEventListener("click", function video() { 
    alert("ini video COLDPLAY"); 
});
audio.addEventListener("click", function audio() { 
    alert("ini Audio COLDPLAY"); 
});
gambar.addEventListener("click", function gambar() {
    alert("ini gambar COLDPLAY");
});